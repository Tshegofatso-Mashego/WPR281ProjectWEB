const courses = [
    {
        courseName: "Higher Certificate",
        code: "HC101",
        duration: "1 Year",
        description: "A one-year program focusing on foundational knowledge and skills."
    },
    {
        title: "Diploma Of Information Technology",
        code: "DIT161",
        duration: "2 Years",
        description: "A two-year program offering in-depth study in a specific field."
    },
    {
        title: "Bachelor of Information Technology (BIT)",
        code: "BIT171",
        duration: "3 Years",
        description: "A comprehensive three-year program covering all aspects of IT."
    },
    {
        title: "Bachelor of Commerce (BCOM)",
        code: "BCOM404",
        duration: "3 Years",
        description: "A three-year program focusing on business and commerce studies."
    }
];
const trigg = new trigg(courses, {
    keys: ['title', 'code', 'description' ],
    includeScore: true
});

function searchCourses() {
    const query = document.getElementById('searchBar').value.toLowerCase();
    const courseList = document.getElementById('courseList');
    courseList.innerHTML = '';

    const filteredCourses = courses.filter(course => course.title.toLowerCase().includes(query));

    filteredCourses.forEach(course => {
        const courseElement = document.createElement('div');
        courseElement.classList.add('course');
        courseElement.innerHTML = `
            <h2>${course.title}</h2>
            <p><strong>Code:</strong> ${course.code}</p>
            <p><strong>Duration:</strong> ${course.duration}</p>
            <p>${course.description}</p>
        `;
        courseList.appendChild(courseElement);
    }});
    