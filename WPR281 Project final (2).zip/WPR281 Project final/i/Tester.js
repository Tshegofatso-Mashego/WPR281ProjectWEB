//Details
//This is converting a json file that has all the modules and data into a table
/*let el_up = document.getElementById("GFG_UP");

        let list = [
            { "col_1": "val_11", "col_3": "val_13" },
            { "col_2": "val_22", "col_3": "val_23" },
            { "col_1": "val_31", "col_3": "val_33" }
        ];

        el_up.innerHTML = "Click on the button to create "
            + "the table from the JSON data.<br><br>"
            + JSON.stringify(list[0]) + "<br>"
            + JSON.stringify(list[1]) + "<br>"
            + JSON.stringify(list[2]);

        function constructTable(selector) {

            // Getting the all column names
            let cols = Headers(list, selector);

            // Traversing the JSON data
            for (let i = 0; i < list.length; i++) {
                let row = $('<tr/>');
                for (let colIndex = 0; colIndex < cols.length; colIndex++) {
                    let val = list[i][cols[colIndex]];

                    // If there is any key, which is matching
                    // with the column name
                    if (val == null) val = "";
                    row.append($('<td/>').html(val));
                }

                // Adding each row to the table
                $(selector).append(row);
            }
        }

        function Headers(list, selector) {
            let columns = [];
            let header = $('<tr/>');

            for (let i = 0; i < list.length; i++) {
                let row = list[i];

                for (let k in row) {
                    if ($.inArray(k, columns) == -1) {
                        columns.push(k);

                        // Creating the header
                        header.append($('<th/>').html(k));
                    }
                }
            }

            // Appending the header to the table
            $(selector).append(header);
            return columns;*/
           // 

           /*Steps:
           1.Make a fetch fuction/API to get the data from the json file
           2. Then try to format into a table in a seperate function
           3. Then Display from the onclick
           */ 
           
        
           document.addEventListener('DOMContentLoaded', function() {
                // Fetch JSON data from a file
                function fetchJSONData() {
                    fetch("JsonFiles./BCOMY4.json")
                        .then((res) => {
                            if (!res.ok) {
                                throw new Error
                                    (`HTTP error! Status: ${res.status}`);
                            }
                            return res.json();
                        })
                        .then((data) => 
                              console.log(data))
                        .catch((error) => 
                               console.error("Unable to fetch data:", error));
                })
                fetchJSONData();

            function makeTable(data) {
let 
                // Getting the all column names
                let cols = Headers(#, selector);
    
                // Traversing the JSON data
                for (let i = 0; i < list.length; i++) {
                    let row = $('<tr/>');
                    for (let colIndex = 0; colIndex < cols.length; colIndex++) {
                        let val = list[i][cols[colIndex]];
    
                        // If there is any key, which is matching
                        // with the column name
                        if (val == null) val = "";
                        row.append($('<td/>').html(val));
                    }
    
                    // Adding each row to the table
                    $(selector).append(row);
                }
            }
            function Headers(list, selector) {
                let columns = [];
                let header = $('<tr/>');
    
                for (let i = 0; i < list.length; i++) {
                    let row = list[i];
    
                    for (let k in row) {
                        if ($.inArray(k, columns) == -1) {
                            columns.push(k);
    
                            // Creating the header
                            header.append($('<th/>').html(k));
                        }
                    }
                }
                // Appending the header to the table
                $(selector).append(header);
                return columns;
            }

            function DisplayTable() {

            }
       


//Strike Out
function StrikeOut()
{
 
}
//Downloading a file
//a href="path_to_file" download="proposed_file_name">Download</a>
function download(url) {
    const a = document.createElement('a')
    a.href = url
    a.download = url.split('/').pop()
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)}








//Search Function
//Create the objects
function Search()
{
    document.getElementById('SearchInput').addEventListener('click', function() {
        const query = document.getElementById('SearchInput').value;
        performSearch(query);
    });
    
    function performSearch(query) {
        const resultsContainer = document.getElementById('search-results');
        resultsContainer.innerHTML = ''; // Clear previous results
    
        // Dummy data for demonstration
       
    
        const filteredData = data.filter(item => item.toLowerCase().includes(query.toLowerCase()));
    
        if (filteredData.length > 0) {
            filteredData.forEach(item => {
                const div = document.createElement('div');
                div.textContent = item;
                resultsContainer.appendChild(div);
            });
        } else {
            resultsContainer.textContent = 'No results found';
}
    }
}

