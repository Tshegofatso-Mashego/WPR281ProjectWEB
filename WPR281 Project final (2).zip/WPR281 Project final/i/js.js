//Storage of Data
const courses =[
    {
        coursename:"Higher Certificate of Information Technology",
        courseid:"HC151",
        description: "Introductory course to the world of IT",
        Credits: 360,
        NQF: 5,
        startDate: "",
        duration: "1 year",
        view: 'Course views/#',
        venues:["Pretoria", "Stellenbosch", "Kempton Park"],
        modules:[{
            core:
            {moduleid: "MATH151",
            },
            electives:
             {moduleid:'SWA151'}
        }

        ],
    },
  {
        modulename:"Diploma of Information Technology",
        moduleid:"DIT161",
        description: "Intermediate course to the world of IT",
        Credits: 360,
        NQF: 6,
        startDate: "",
        duration: "2 1/2 year and 6 months of Training",
        view: 'Course views/Course-Structure_Diploma-in-Information-Technology.pdf',
        venues:["Pretoria", "Stellenbosch", "Kempton Park"],
        modules:[
            {
                core:
                {moduleid: "MATH161",
                },
                electives:
                 {moduleid:'SWA161'}
            }

        ]
    },

    {
        modulename:"Bachelor of Information Technology",
        moduleid:"BIT171",
        description: " Intermidate course to the world of IT",
        Credits: 360,
        NQF: 7,
        startDate: "",
        duration: "3 years",
        view: 'Course views/#',
        venues:["Pretoria", "Stellenbosch", "Kempton Park"],
        modules:[
            {
                core:
                {moduleid: "MATH171",
                },
                electives:
                 {moduleid:'SWA161'}
            }

        ],
    },
 {
        modulename:"Bachelor of Computing",
        moduleid:"BCOM181",
        description: "Ulimate course to the world of IT",
        Credits: 360,
        NQF: 8,
        startDate: "",
        duration: "3 year",
        view: 'Course views/#',
        venues:["Pretoria", "Stellenbosch", "Kempton Park"],
        modules:[
            {
                core:
                {moduleid: "MATH181",
                },
                electives:
                 {moduleid:'SWA181'}
            }

        ]
    },
]