
<script src="BCOMY1"></script>
    // Function to generate table from JSON data
    function generateTable(jsonData) {
        const tableHeader = document.getElementById('table-header');
        const tableBody = document.getElementById('table-body');

        // Get headers from JSON keys
        const headers = Object.keys(jsonData[0]);

        // Create table header
        headers.forEach(header => {
            const th = document.createElement('th');
            th.innerText = header.charAt(0).toUpperCase() + header.slice(1);
            tableHeader.appendChild(th);
        });

        // Create table rows
        jsonData.forEach(item => {
            const tr = document.createElement('tr');
            headers.forEach(header => {
                const td = document.createElement('td');
                td.innerText = item[header];
                tr.appendChild(td);
            });
            tableBody.appendChild(tr);
        });
    }

    // Call the function to generate the table
    generateTable(jsonData);
    
    document.addEventListener('DOMContentLoaded', function() {
        // Fetch JSON data from a file
        fetch('data.json')
            .then(response => response.json())
            .then(jsonData => {
                // Call the function to generate the table
                generateTable(jsonData);
            })
            .catch(error => console.error('Error fetching JSON data:', error));
    });
;